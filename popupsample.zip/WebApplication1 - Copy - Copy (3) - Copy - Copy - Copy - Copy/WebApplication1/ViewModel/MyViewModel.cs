﻿using DbModel;

namespace WebApplication1.ViewModel
{
    public class MyViewModel
    {

        public List<GroupList> GroupLists { get; set; }
        public List<Schedule> Schedules { get; set; }
    }
}
