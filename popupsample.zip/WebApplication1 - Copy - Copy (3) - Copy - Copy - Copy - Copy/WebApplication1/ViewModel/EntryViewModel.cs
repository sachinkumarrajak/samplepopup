﻿using DbModel;

namespace WebApplication1.ViewModel
{
    public class EntryViewModel
    {
        public MainTableModel MainTableModel { get; set; }
        public GroupModel GroupModel { get; set; }
        public PcsModel PcsModel { get; set; }

        public IEnumerable<MainTableModel> MainTableModelData { get; set; }
        public IEnumerable<GroupModel> GroupModelData { get; set; }
        public IEnumerable<PcsModel> PcsModelData { get; set; }
    }

}
