﻿using DataAccess.Repository.IRepository;
using DbModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceDb;
using WebApplication1.ViewModel;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class popController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly VersionAvailabilityService _versionAvailabilityService;
        public popController(IUnitOfWork unitOfWork, VersionAvailabilityService versionAvailabilityService)
        {
            _unitOfWork = unitOfWork;
            _versionAvailabilityService = versionAvailabilityService;
        }
        [HttpPost]
        public IActionResult CheckVersionAvailability(string version)
        {
            bool isAvailable = _versionAvailabilityService.IsVersionAvailable(version);

            if (isAvailable)
            {
                return Json(new { success = true, message = "Version is available." });
            }
            else
            {
                return Json(new { success = false, message = "Version is not available." });
            }
        }

        [HttpGet]
        public JsonResult IsVersionAvailable(string version)
        {
            // Check if the version is available (you'll implement this logic)
            bool isAvailable = _versionAvailabilityService.IsVersionAvailable(version);

            return Json(isAvailable);
        }
        public IActionResult Index()
        {
            var groups = _unitOfWork.Groplist.GetAllGrlist().ToList();
            // return View(groups); // Pass the group data to the Index view

            var viewModel = new MyViewModel
            {
                GroupLists = _unitOfWork.Groplist.GetAllGrlist().ToList(),
                Schedules = _unitOfWork.Schedule.GetAllSchedule().ToList()
            };

            return View(viewModel);
        }

        public IActionResult GetGroups()
        {
            // Fetching groups data as needed, assuming it's similar to the Index action
            var groups = _unitOfWork.Groplist.GetAllGrlist().ToList();
            return Json(groups); // Return the groups as JSON if needed
        }
        //[HttpPost]
        //public IActionResult CreateSchedule([FromBody] Schedule schedule)
        //{
        //    // Replace null values with 'All'
        //    schedule.SelectedGroups = schedule.SelectedGroups ?? "All";
        //    schedule.SelectedPCs = schedule.SelectedPCs ?? "All";

        //    try
        //    {
        //        // Call your data access layer to save the schedule to the database
        //        _unitOfWork.Schedule.AddSchedule(schedule);
        //     //   _unitOfWork.Complete(); // Save changes to the database

        //        return Json(new { success = true, message = "Schedule saved successfully." });
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { success = false, message = "An error occurred while saving the schedule." });
        //    }
        //}
        [HttpPost]
        public IActionResult CreateSchedule(string version, string targetSettings, bool scheduleEnabled, DateTime startDate, DateTime endDate, string selectedGroups, string selectedPCs)
        {
            // Logic to save the schedule based on the target settings
            Schedule schedule = new Schedule
            {
                Version = version,
                TargetSettings = targetSettings,
                ScheduleEnabled = scheduleEnabled,
                StartDate = startDate,
                EndDate = endDate
            };

            if (targetSettings == "userAll")
            {
                // Save for User All
                schedule.SelectedGroups = "All";
                schedule.SelectedPCs = "All";
            }
            else if (targetSettings == "groupSettings")
            {
                // Save for Group Settings
                schedule.SelectedGroups = selectedGroups;
                schedule.SelectedPCs = "All";
            }
            else if (targetSettings == "pcSettings")
            {
                // Save for PC Settings
                schedule.SelectedGroups = "All";
                schedule.SelectedPCs = selectedPCs;
            }

            _unitOfWork.Schedule.AddSchedule(schedule);
            return RedirectToAction("Index"); // Or any other action
        }
    }
}
