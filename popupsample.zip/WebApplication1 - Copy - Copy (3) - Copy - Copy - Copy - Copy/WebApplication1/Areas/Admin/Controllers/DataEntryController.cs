﻿using DataAccess.Repository;
using DataAccess.Repository.IRepository;
using DbModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.ViewModel;
using System.Collections.Generic;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class DataEntryController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public DataEntryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult EntryForm()
        {
            var viewModel = new EntryViewModel
            {
                MainTableModel = new MainTableModel(),
                GroupModel = new GroupModel(),
                PcsModel = new PcsModel(),
                MainTableModelData = new List<MainTableModel>(),  // Initialize the MainTableModelData property
                GroupModelData = new List<GroupModel>(),  // Initialize the GroupModelData property
                PcsModelData = new List<PcsModel>()  // Initialize the PcsModelData property
            };
            return View(viewModel);
        }


        // Action to handle inserting data for MainTable, Groups, and PCs
        [HttpPost]
        public IActionResult InsertData(EntryViewModel viewModel)
        {
            if (viewModel.MainTableModel != null)
            {
                // Insert main table data
                _unitOfWork.MainTable.AddM(viewModel.MainTableModel);
                _unitOfWork.Save(); // Save changes to the main table
            }

            if (viewModel.GroupModel != null)
            {
                // Insert group data
                _unitOfWork.Group.AddG(viewModel.GroupModel);
                _unitOfWork.Save(); // Save changes to the group table
            }

            if (viewModel.PcsModel != null)
            {
                // Insert PC data
                _unitOfWork.PC.AddPC(viewModel.PcsModel);
                _unitOfWork.Save(); // Save changes to the PC table
            }

            // Redirect to view the data
            return RedirectToAction("ViewData");
        }

        // Action to view all data
        public IActionResult ViewData()
        {
            var viewModel = new EntryViewModel
            {
                MainTableModelData = _unitOfWork.MainTable.GetAlls(),
                GroupModelData = _unitOfWork.Group.GetAllG(),
                PcsModelData = _unitOfWork.PC.GetAllPC()
            };
            return View(viewModel);
        }
    }
}
