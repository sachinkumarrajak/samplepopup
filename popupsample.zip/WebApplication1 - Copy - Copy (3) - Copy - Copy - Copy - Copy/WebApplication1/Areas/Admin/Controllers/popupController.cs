﻿using DataAccess.Repository.IRepository;
using DbModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class popupController : Controller
    {

        private readonly IUnitOfWork _unitOfWork;

        public popupController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            var groups = _unitOfWork.Groplist.GetAllGrlist().ToList();
            return View(groups); // Pass the group data to the Index view
        }

        public IActionResult GetGroups()
        {
            // Fetching groups data as needed, assuming it's similar to the Index action
            var groups = _unitOfWork.Groplist.GetAllGrlist().ToList();
            return Json(groups); // Return the groups as JSON if needed
        }
        [HttpPost]
        public IActionResult CreateSchedule([FromBody] Schedule schedule)
        {
            try
            {
                if (schedule != null)
                {
                    _unitOfWork.Schedule.AddSchedule(schedule);  // This method saves changes internally
                    return Json(new { success = true, message = "Schedule created successfully." });
                }

                return Json(new { success = false, message = "Invalid schedule data." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while saving the schedule." });
            }
        }


    }
}
