﻿using DataAccess.Repository.IRepository;
using DbModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class CategoryController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {

            IEnumerable<Employee> objCategoryList = _unitOfWork.employee.GetAll();
            return View(objCategoryList);
        }
        public IActionResult Details(int id)
        {
            var employee = _unitOfWork.employee.GetEmployeeWithFiles(id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }


       
        [HttpPost]

        [AllowAnonymous]
        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        {
            if (await _unitOfWork.employee.UploadEmployeeFile(employeeId, file))
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            return RedirectToAction("Details", new { id = employeeId }); // You can handle the error scenario differently
        }

        public IActionResult DownloadFile(int id, bool view = false)
        {
            var employeeFile = _unitOfWork.employee.GetEmployeeFileById(id);
            if (employeeFile == null)
            {
                return NotFound();
            }

            if (view)
            {
                var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
                return File(fileStream, "text/plain");
            }
            else
            {
                var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
                return File(fileStream, "application/octet-stream", employeeFile.FileName);
            }
        }


        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var filePath = Path.Combine("wwwroot", "uploads", fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now // You can use DateTime.UtcNow for UTC time
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    return View();
        //}
        public IActionResult Upload()
        {
            // Assuming you have a file repository injected as _fileUploadRepository
            var files = _unitOfWork.FILES.GetAllAsync().Result; // Synchronous call for simplicity

            return View(files);
        }
        [HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var filePath = Path.Combine("wwwroot", "uploads", fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now // You can use DateTime.UtcNow for UTC time
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles); // Assuming your view is named "Upload.cshtml"
        //}

        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());

        //            // Create the versioned directory
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now // You can use DateTime.UtcNow for UTC time
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles); // Assuming your view is named "Upload.cshtml"
        //}
       

        [HttpPost]
        public async Task<IActionResult> DeleteFile(int fileId)
        {
            try
            {
                // Delete the file record and associated file
                await _unitOfWork.FILES.DeleteAsync(fileId);

                ToastrSuccess("File deleted successfully.");

            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error deleting file: {ex.Message}";
            }

            // Redirect to the Upload action to refresh the list of uploaded files
            return RedirectToAction("Upload");
        }
        [HttpPost]
        public async Task<IActionResult> ToggleStatus(int fileId, bool status)
        {
            var fileRecord = await _unitOfWork.FILES.GetByIdAsync(fileId);

            if (fileRecord != null)
            {
                fileRecord.IsActive = status;

                // Update the file record with the new status
                await _unitOfWork.FILES.UpdateStatusAsync(fileRecord);

                ViewBag.Message = "Status updated successfully.";

                // Redirect to the Upload action to refresh the list of uploaded files
                return RedirectToAction("Upload");
            }

            ViewBag.Message = "File not found.";

            // Redirect to the Upload action to refresh the list of uploaded files
            return RedirectToAction("Upload");
        }

        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file, string version)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now,
        //                IsActive = true,  // Set the initial status to active
        //                Version = version  // Save the version
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles);
        //}

        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file, string version, string platform)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now,
        //                IsActive = true,  // Set the initial status to active
        //                Version = version,  // Save the version
        //                Platform = platform // Save the platform
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles);
        //}


        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file, string version, string platform, bool isActive)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now,
        //                IsActive = isActive,
        //                Version = version,
        //                Platform = platform
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles);
        //}


        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file, string version, string platform)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Retrieve the checkbox value
        //            bool isActive = Request.Form["isActive"] == "on"; // Check if the checkbox was checked

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now,
        //                IsActive = isActive,
        //                Version = version,
        //                Platform = platform
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles);
        //}

        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file, string version, string platform)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
        //            Directory.CreateDirectory(versionedDirectory);

        //            var filePath = Path.Combine(versionedDirectory, fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Retrieve the checkbox value
        //            bool isActive = Request.Form["isActive"] == "on"; // Check if the checkbox was checked

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now,
        //                IsActive = isActive,
        //                Version = version,
        //                Platform = platform
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            // Redirect to a different action after successful submission
        //            return RedirectToAction("UploadSuccess");
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    // Fetch the list of uploaded files and pass them to the view
        //    var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

        //    return View("Upload", uploadedFiles);
        //}
        //public IActionResult UploadSuccess()
        //{
        //    ViewBag.Message = "File uploaded successfully.";
        //    return View();
        //}


        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file, string version, string platform)
        {
            if (file != null && file.Length > 0)
            {
                try
                {
                    var fileName = Path.GetFileName(file.FileName);

                    var existingFile = await _unitOfWork.FILES.GetFileByVersionAsync(version);
                    if (existingFile != null)
                    {
                        ModelState.AddModelError("Version", "A file with the specified version already exists. Please choose a different version.");
                        return RedirectToAction("Upload");  // Redirect to get the Upload view
                    }
                    var versionedDirectory = Path.Combine("wwwroot", "buildupload", Guid.NewGuid().ToString());
                    Directory.CreateDirectory(versionedDirectory);

                    var filePath = Path.Combine(versionedDirectory, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Retrieve the checkbox value
                    bool isActive = Request.Form["isActive"] == "on"; // Check if the checkbox was checked

                    // Create a new record for the database
                    var fileRecord = new FileUpload
                    {
                        FileName = fileName,
                        FilePath = filePath,
                        UploadDate = DateTime.Now,
                        IsActive = isActive,
                        Version = version,
                        Platform = platform
                    };

                    // Add the record to the repository
                    await _unitOfWork.FILES.AddAsync(fileRecord);

                    // Display a toast message
                    ToastrSuccess("File uploaded successfully!");

                    return RedirectToAction("Upload");
                }
                catch (Exception ex)
                {
                    // Display an error toast message
                    ToastrError($"Error uploading file: {ex.Message}");
                }
            }
            else
            {
                // Display a warning toast message
                ToastrWarning("Please choose a file to upload.");
            }

            // Fetch the list of uploaded files and pass them to the view
            var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

            return View("Upload", uploadedFiles);
        }

        private void ToastrSuccess(string message)
        {
            Toastr("success", message);
        }

        private void ToastrWarning(string message)
        {
            Toastr("warning", message);
        }

        private void ToastrError(string message)
        {
            Toastr("error", message);
        }

        private void Toastr(string type, string message)
        {
            Toastr("toast-" + type, type, message);
        }

        private void Toastr(string cssClass, string type, string message)
        {
            TempData["ToastrCssClass"] = cssClass;
            TempData["ToastrType"] = type;
            TempData["ToastrMessage"] = message;
        }

    }
}
