﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;

namespace DbModel
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(30)]
        [DisplayName("Category Name")]
        public string Name { get; set; }
        [DisplayName("Display Order")]
        [Range(1, 100, ErrorMessage = "Display Order must be between 1-100")]
        public int DisplayOrder { get; set; }
    }
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public List<EmployeeFile> EmployeeFiles { get; set; }
        public List<EmployeeDepartment> EmployeeDepartments { get; set; }

        // Other properties
    }

    public class EmployeeFile
    {
        public int ID { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public DateTime FileCreatedDate { get; set; } // Add this property
        public int EmployeeID { get; set; }
        public Employee Employee { get; set; }
    }

    public class Department
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public List<EmployeeDepartment> EmployeeDepartments { get; set; }
        // Other properties
    }

    public class EmployeeDepartment
    {
        [Key]
        public int EmployeeID { get; set; }
        public int DepartmentID { get; set; }
        public Employee Employee { get; set; }
        public Department Department { get; set; }
    }

    public class FileUpload
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public DateTime UploadDate { get; set; }
        public bool IsActive { get; set; } // New property to track status (active/inactive)
        public string Version { get; set; } // New property for version number
        public string Platform { get; set; } // New property for the platform
    }
    public class MainTableModel
    {
        public int Id { get; set; }
        public string Version { get; set; }
        public string Isschudle { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }

        public List<GroupModel> Groups { get; set; }
        public List<PcsModel> Pcs { get; set; }
    }
    public class GroupModel
    {
        [Key]
        public int GroupId { get; set; }
        public string GroupName { get; set; }
    }

    public class GroupList
    {
        [Key]
        public int GroupId { get; set; }
        public string GroupName { get; set; }
    }

    public class PcsModel
    {
        [Key]
        public int PcsId { get; set; }
        public string PcsName { get; set; }
    }

    public class Schedule
    {
        public int Id { get; set; }
       
        public string Version { get; set; }
        public string TargetSettings { get; set; }
        public bool ScheduleEnabled { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SelectedGroups { get; set; }
        public string SelectedPCs { get; set; }
    }


}