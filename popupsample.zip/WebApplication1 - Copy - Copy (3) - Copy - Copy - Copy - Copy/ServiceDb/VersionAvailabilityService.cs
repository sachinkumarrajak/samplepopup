﻿using DataAccess.Repository.IRepository;
using DbModel;

namespace ServiceDb
{
    public class Class1
    {

    }
    // YourServiceProject/VersionAvailabilityService.cs


    public class VersionAvailabilityService
    {
        private readonly IRepository<Schedule> _scheduleRepository;

        public VersionAvailabilityService(IRepository<Schedule> scheduleRepository)
        {
            _scheduleRepository = scheduleRepository;
        }

        public bool IsVersionAvailable(string version)
        {
            return _scheduleRepository.IsVersionAvailable(version);
        }
    }


}