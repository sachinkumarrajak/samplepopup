﻿
using DataAccess.Data;
using DbModel;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataAccess.Repository.IRepository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly ApplicationDbContext _db;
        internal DbSet<T> dbSet;

        public Repository(ApplicationDbContext db)
        {
            _db= db;
            //_db.ShoppingCarts.Include(u => u.Product).Include(u=>u.CoverType);
            this.dbSet= _db.Set<T>();
        }
        public void Add(T entity)
        {
            dbSet.Add(entity);
        }
        //includeProp - "Category,CoverType"
        public IEnumerable<T> GetAll(Expression<Func<T, bool>>? filter=null, string? includeProperties = null)
        {
            IQueryable<T> query = dbSet;
            if (filter != null)
            {
                query = query.Where(filter);
            }
            if (includeProperties != null)
            {
                foreach(var includeProp in includeProperties.Split(new char[] { ','}, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }
            return query.ToList();
        }
        public EmployeeFile GetEmployeeFileById(int id)
        {
            return _db.EmployeeFiles.FirstOrDefault(ef => ef.ID == id);
        }

        public Employee GetEmployeeWithFiles(int id)
        {
            return _db.Employees
                .Include(e => e.EmployeeFiles)
                .FirstOrDefault(e => e.ID == id);
        }
        //public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        return false;
        //    }

        //    var fileName = Path.GetFileName(file.FileName);
        //    var filePath = Path.Combine("wwwroot", "uploads", fileName); // Path to the wwwroot/uploads folder

        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await file.CopyToAsync(stream);
        //    }

        //    var employeeFile = new EmployeeFile
        //    {
        //        FileName = fileName,
        //        FilePath = filePath,
        //        EmployeeID = employeeId
        //    };

        //    _db.EmployeeFiles.Add(employeeFile);
        //    await _db.SaveChangesAsync();

        //    return true;
        //}
        //public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        return false;
        //    }

        //    var fileName = Path.GetFileName(file.FileName);
        //    var filePath = Path.Combine("wwwroot", "uploads", fileName); // Path to the wwwroot/uploads folder

        //    // Check if a file with the same name already exists
        //    var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

        //    if (existingFile != null)
        //    {
        //        // Delete the old file record and the associated file
        //        _db.EmployeeFiles.Remove(existingFile);
        //        await _db.SaveChangesAsync();
        //        File.Delete(existingFile.FilePath);
        //    }

        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await file.CopyToAsync(stream);
        //    }

        //    var employeeFile = new EmployeeFile
        //    {
        //        FileName = fileName,
        //        FilePath = filePath,
        //        EmployeeID = employeeId
        //    };

        //    _db.EmployeeFiles.Add(employeeFile);
        //    await _db.SaveChangesAsync();

        //    return true;
        //}


        public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return false;
            }

            var fileName = Path.GetFileName(file.FileName);
            var employeeFolder = Path.Combine("wwwroot", "uploads", employeeId.ToString());

            // Create the employee-specific folder if it doesn't exist
            if (!Directory.Exists(employeeFolder))
            {
                Directory.CreateDirectory(employeeFolder);
            }
                       
            var filePath = Path.Combine(employeeFolder, fileName);
          //  DateTime fileCreatedDate = File.GetCreationTime(filePath);
            DateTime lastModifiedDate = File.GetLastWriteTime(filePath);
            // Check if a file with the same name already exists
            var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

            if (existingFile != null)
            {
                // Delete the old file record and the associated file
                _db.EmployeeFiles.Remove(existingFile);
                await _db.SaveChangesAsync();
                File.Delete(existingFile.FilePath);
            }

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var employeeFile = new EmployeeFile
            {
                FileName = fileName,
                FilePath = filePath,
                FileCreatedDate = lastModifiedDate,
                EmployeeID = employeeId
            };

            _db.EmployeeFiles.Add(employeeFile);
            await _db.SaveChangesAsync();

            return true;
        }


        public async Task<bool> UploadEmployeeFile(int employeeId, IFormFile file, DateTime lastModifiedDate)
        {
            if (file == null || file.Length == 0)
            {
                return false;
            }

            var fileName = Path.GetFileName(file.FileName);
            var employeeFolder = Path.Combine("wwwroot", "uploads", employeeId.ToString());

            // Create the employee-specific folder if it doesn't exist
            if (!Directory.Exists(employeeFolder))
            {
                Directory.CreateDirectory(employeeFolder);
            }

            var filePath = Path.Combine(employeeFolder, fileName);
            //  DateTime fileCreatedDate = File.GetCreationTime(filePath);
             lastModifiedDate = File.GetLastWriteTime(filePath);
            // Check if a file with the same name already exists
            var existingFile = await _db.EmployeeFiles.FirstOrDefaultAsync(e => e.FileName == fileName && e.EmployeeID == employeeId);

            if (existingFile != null)
            {
                // Delete the old file record and the associated file
                _db.EmployeeFiles.Remove(existingFile);
                await _db.SaveChangesAsync();
                File.Delete(existingFile.FilePath);
            }

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var employeeFile = new EmployeeFile
            {
                FileName = fileName,
                FilePath = filePath,
                FileCreatedDate = lastModifiedDate,
                EmployeeID = employeeId
            };

            _db.EmployeeFiles.Add(employeeFile);
            await _db.SaveChangesAsync();

            return true;
        }
        public T GetFirstOrDefault(Expression<Func<T, bool>> filter, string? includeProperties = null, bool tracked = true)
        {
            if (tracked)
            {
                IQueryable<T> query = dbSet;

                query = query.Where(filter);
                if (includeProperties != null)
                {
                    foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        query = query.Include(includeProp);
                    }
                }
                return query.FirstOrDefault();
            }
            else
            {
                IQueryable<T> query = dbSet.AsNoTracking();

                query = query.Where(filter);
                if (includeProperties != null)
                {
                    foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        query = query.Include(includeProp);
                    }
                }
                return query.FirstOrDefault();
            }
            
        }

        public void Remove(T entity)
        {
            dbSet.Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entity)
        {
            dbSet.RemoveRange(entity);
        }


        public async Task<FileUpload> GetByIdAsync(int id)
        {
            return await _db.FileUploads.FindAsync(id);
        }

        public async Task<IEnumerable<FileUpload>> GetAllAsync()
        {
            return await _db.FileUploads.ToListAsync();
        }


        public async Task<FileUpload> GetFileByVersionAsync(string version)
        {
            return await _db.FileUploads.FirstOrDefaultAsync(f => f.Version == version);
        }
        public async Task AddAsync(FileUpload fileUpload)
        {
            _db.FileUploads.Add(fileUpload);
            await _db.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var fileUpload = await GetByIdAsync(id);
            if (fileUpload != null)
            {
                // Delete the file from the file system
                System.IO.File.Delete(fileUpload.FilePath);

                _db.FileUploads.Remove(fileUpload);
                await _db.SaveChangesAsync();
            }
        }
        public async Task UpdateStatusAsync(FileUpload fileUpload)
        {
            _db.FileUploads.Update(fileUpload);
            await _db.SaveChangesAsync();
        }
        public void AddM(MainTableModel mainTable)
        {
            _db.MainTable.Add(mainTable);
            _db.SaveChanges();
        }

        public IEnumerable<MainTableModel> GetAlls()
        {
            return _db.MainTable.ToList();
        }
        public void AddG(GroupModel group)
        {
            _db.Groups.Add(group);
            _db.SaveChanges();
        }

        public IEnumerable<GroupModel> GetAllG()
        {
            return _db.Groups.ToList();
        }
        public void AddPC(PcsModel pc)
        {
            _db.Pcs.Add(pc);
            _db.SaveChanges();
        }

        public IEnumerable<PcsModel> GetAllPC()
        {
            return _db.Pcs.ToList();
        }

        public IEnumerable<GroupList> GetAllGrlist()
        {
            return _db.GroupList.ToList();
        }

        public IEnumerable<Schedule> GetAllSchedule()
        {
            return _db.Schedules.ToList();
        }


        //IEnumerable<T> IRepository<Gr.GetAllGroupList()
        //{
        //    return _db.GroupList.ToList();
        //}


        public void AddSchedule(Schedule schedule)
        {
            _db.Schedules.Add(schedule);
            _db.SaveChanges();
        }
        public bool IsVersionAvailable(string version)
        {
            // Check if the version exists in the database
            return _db.Schedules.Any(schedule => schedule.Version == version);
        }
        

    }

    public class CheckVersionAvailabilityAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var version = value as string;

            // Retrieve the repository instance from the validation context
            var repo = (IScheduleRepository)validationContext.GetService(typeof(IScheduleRepository));

            if (repo != null && repo.IsVersionAvailable(version))
            {
                return new ValidationResult("Version for this build is already scheduled.");
            }

            return ValidationResult.Success;
        }
    }


}
