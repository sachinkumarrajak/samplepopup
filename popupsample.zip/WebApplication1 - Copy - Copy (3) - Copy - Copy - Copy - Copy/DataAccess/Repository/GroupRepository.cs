﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class GroupRepository : Repository<GroupModel>, IGroupRepository
    {
        private ApplicationDbContext _db;

        public GroupRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(IGroupRepository obj)
        {
            // _db.Ifile.Update(obj);
        }//

        public void Update(GroupModel obj)
        {
            //_db.FileUpload.Update(obj);
            // throw new NotImplementedException();
        }
    }
}
