﻿
using DataAccess.Data;
using DataAccess.Repository;
using DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.DataAccess.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext _db;

        public UnitOfWork(ApplicationDbContext db) 
        {
            _db = db;
            Category = new CategoryRepository(_db);
            employee= new employeeRepostiry(_db);
            FILES = new iFileRepsotry(_db);
            MainTable = new MainTableRepository(_db);
            Group = new GroupRepository(_db);
            PC=new PCRepository(_db);
            Groplist=new groupListrepostry(_db);
            Schedule=new ScheduleRepository(_db);
        }
        public ICategoryRepository Category { get; private set; }

        public Iemployee employee { get; private set; }
        public IMainTableRepository MainTable { get; private set; }

        public Ifile FILES { get; private set; }

        public IGroupRepository Group { get; private set; }

        public IPCRepository PC { get; private set; }

        public IgroupList Groplist { get; private set; }

        public IScheduleRepository Schedule { get; private set; }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
