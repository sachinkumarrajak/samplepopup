﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository.IRepository
{
    public interface IUnitOfWork
    {
        ICategoryRepository Category {  get; }
        Iemployee employee { get; }

        Ifile FILES { get; }
        IMainTableRepository MainTable { get; }

        IGroupRepository Group { get; }
        IPCRepository PC { get; }
        IgroupList Groplist { get; }
        IScheduleRepository Schedule { get; }
        void Save();
    }
}
