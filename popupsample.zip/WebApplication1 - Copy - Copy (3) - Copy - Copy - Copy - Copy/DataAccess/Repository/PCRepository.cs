﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    internal class PCRepository : Repository<PcsModel>, IPCRepository
    {
        private ApplicationDbContext _db;

        public PCRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(PcsModel obj)
        {
            _db.Pcs.Update(obj);
        }
    }
}
