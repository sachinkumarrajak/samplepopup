﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    internal class groupListrepostry : Repository<GroupList>, IgroupList
    {
        private ApplicationDbContext _db;

        public groupListrepostry(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(GroupList obj)
        {
            _db.GroupList.Update(obj);
        }
    }
}
