﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    internal class ScheduleRepository : Repository<Schedule>, IScheduleRepository
    {
        private ApplicationDbContext _db;

        public ScheduleRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(Schedule obj)
        {
            _db.Schedules.Update(obj);
        }
    }
}
