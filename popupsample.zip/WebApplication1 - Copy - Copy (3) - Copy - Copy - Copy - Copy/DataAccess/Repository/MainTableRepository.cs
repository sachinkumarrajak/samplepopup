﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    internal class MainTableRepository : Repository<MainTableModel>, IMainTableRepository
    {

        private ApplicationDbContext _db;

        public MainTableRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(MainTableModel obj)
        {
            _db.MainTable.Update(obj);
        }
    }
}
